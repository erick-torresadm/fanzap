module.exports = {
    extends: ['@commitlint/config-conventional'],
    rules: {
        'header-max-length': [2, 'always', 72],
        'type-enum': [
            2,
            'always',
            [
                'feat',
                'fix',
                'docs',
                'style',
                'refactor',
                'perf',
                'test',
                'build',
                'ci',
                'chore',
                'types',
                'revert',
                'infra',
            ],
        ],
        'type-case': [0],
        'scope-case': [0],
        'subject-case': [0],
        'subject-exclamation-mark': [0],
    },
};
